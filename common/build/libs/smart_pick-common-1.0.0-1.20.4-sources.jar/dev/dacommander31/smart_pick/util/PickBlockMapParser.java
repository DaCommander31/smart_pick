package dev.dacommander31.smart_pick.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import dev.dacommander31.smart_pick.platform.Platform;
import dev.dacommander31.smart_pick.platform.SmartPickPlatform;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class PickBlockMapParser {
    public static Map<class_1792, List<class_1792>> parse(JsonObject obj) {
        Map<class_1792, List<class_1792>> map = new HashMap<>();

        for (Map.Entry<String, JsonElement> entry : obj.entrySet()) {
            String key = entry.getKey();
            JsonElement value = entry.getValue();
            if (value instanceof JsonPrimitive primitive && primitive.isString()) {
                JsonArray array = new JsonArray();
                array.add(primitive);
                value = array;
            }

            if (!(value instanceof JsonArray block)) {
                continue;
            }

            SmartPickPlatform platform = Platform.get();

            if (key.startsWith("#")) {
                platform.log("Recognised block tag {} containing {}", key, Arrays.toString(getItems(createTagKey(key)).toArray()));
                for (class_1792 keyItem : getItems(createTagKey(key))) {
                    List<class_1792> blockItemEntries = parseEntries(block, keyItem, null);
                    platform.log("Mapping item {} with {}", keyItem.toString(), Arrays.toString(blockItemEntries.toArray()));
                    map.putIfAbsent(keyItem, blockItemEntries);
                }
            } else if (key.startsWith("$")) {
                class_2960 id = new class_2960(key.substring(1));
                class_3300 rm = class_310.method_1551().method_1478();

                class_2960 resourceId = new class_2960(
                        id.method_12836(),
                        "smart_pick/block_tags/" + id.method_12832() + ".json"
                );

                rm.method_14486(resourceId).ifPresent(resource -> {
                    List<class_1792> keyItems = ClientBlockTagParser.parse(resource, new HashSet<>());

                    platform.log(
                            "Recognised client block tag {} containing {}",
                            key, keyItems
                    );

                    for (class_1792 keyItem : keyItems) {
                        List<class_1792> blockItemEntries = parseEntries(block, keyItem, resource);
                        map.putIfAbsent(keyItem, blockItemEntries);
                    }
                });

            } else {
                class_1792 keyItem = getItem(key);
                List<class_1792> blockItemEntries = parseEntries(block, keyItem, null);
                platform.log("Mapping item {} with {}", keyItem, Arrays.toString(blockItemEntries.toArray()));
                map.put(keyItem, blockItemEntries);
            }

        }
        return map;
    }

    private static List<class_1792> parseEntries(JsonArray block, class_1792 keyItem, @Nullable class_3298 resource) {
        Set<class_1792> entries = new LinkedHashSet<>();

        for (JsonElement el : block) {
            String id = el.getAsString();

            if (id.startsWith("#")) {
                class_6862<class_2248> tag = createTagKey(id);
                for (class_1792 item : getItems(tag)) {
                    if (keyItem != null && class_7923.field_41178.method_10221(item).equals(class_7923.field_41178.method_10221(keyItem))) {
                        continue;
                    }
                    entries.add(item);
                }
            } else if (id.startsWith("$")) {
                assert resource != null;
                entries.addAll(ClientBlockTagParser.parse(resource, new HashSet<>()));
            } else {
                class_1792 item = getItem(id);
                if (item != class_1802.field_8162 && !item.equals(keyItem)) {
                    entries.add(item);
                }
            }
        }

        return List.copyOf(entries);
    }

    public static class_1792 getItem(String id) {
        return class_7923.field_41178.method_10223(new class_2960(id));
    }

    public static List<class_1792> getItems(class_6862<class_2248> blockTag) {
        Iterable<class_6880<class_2248>> blocks = class_7923.field_41175.method_40286(blockTag);

        List<class_1792> toReturn = new ArrayList<>();
        for (class_6880<class_2248> blockEntry : blocks) {
            if (blockEntry.comp_349() != class_2246.field_10124) {
                toReturn.add(blockEntry.comp_349().method_8389());
            }
        }
        return toReturn;
    }

    public static class_6862<class_2248> createTagKey(String string) {
        return class_6862.method_40092(class_7924.field_41254, new class_2960(string.substring(1)));
    }
}
