package dev.dacommander31.smart_pick.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.dacommander31.smart_pick.platform.Platform;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_6862;

public class ClientBlockTagParser {

    public static List<class_1792> parse(class_3298 resource, Set<String> visited) {
        String id = resource.method_14480();

        if (!visited.add(id)) {
            return List.of();
        }

        try (InputStream stream = resource.method_14482()) {
            JsonObject obj = JsonParser
                    .parseReader(new InputStreamReader(stream))
                    .getAsJsonObject();

            JsonArray values = obj.getAsJsonArray("values");
            return parseEntries(values, visited);

        } catch (IOException e) {
            Platform.get().error(
                    "Failed to read client block tag at {}", id, e
            );
            return List.of();
        }
    }


    private static List<class_1792> parseEntries(JsonArray block, Set<String> visited) {
        Set<class_1792> entries = new LinkedHashSet<>();
        class_3300 rm = class_310.method_1551().method_1478();

        for (JsonElement el : block) {
            String id = el.getAsString();

            if (id.startsWith("#")) {
                class_6862<class_2248> tag = PickBlockMapParser.createTagKey(id);
                entries.addAll(PickBlockMapParser.getItems(tag));

            } else if (id.startsWith("$")) {
                class_2960 ref = new class_2960(id.substring(1));

                class_2960 resourceId = new class_2960(
                        ref.method_12836(),
                        "smart_pick/block_tags/" + ref.method_12832() + ".json"
                );

                rm.method_14486(resourceId).ifPresent(res ->
                        entries.addAll(parse(res, visited))
                );

            } else {
                class_1792 item = PickBlockMapParser.getItem(id);
                if (item != class_1802.field_8162) {
                    entries.add(item);
                }
            }
        }

        return List.copyOf(entries);
    }

}
