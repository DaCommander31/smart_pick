package dev.dacommander31.smart_pick.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.dacommander31.smart_pick.platform.Platform;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4080;

public class PickBlockCache {
    private static final Map<class_1792, List<class_1792>> CACHE = new HashMap<>();

    public static Map<class_1792, List<class_1792>> getCache() {
        if (!CACHE.isEmpty()) return CACHE;

        class_3300 rm = class_310.method_1551().method_1478();

        rm.method_14488(
                "smart_pick",
                path -> path.method_12832().endsWith("block_pick_map.json")
        ).forEach((id, resource) -> load(resource, id));

        return CACHE;
    }


    private static void load(class_3298 resource, class_2960 id) {
        try (InputStreamReader reader =
                     new InputStreamReader(resource.method_14482(), StandardCharsets.UTF_8)) {

            JsonObject obj = JsonParser.parseReader(reader).getAsJsonObject();
            Platform.get().log("Successfully loaded block pick map for {}", id);
            CACHE.putAll(PickBlockMapParser.parse(obj));

        } catch (Exception e) {
            Platform.get().error(
                    "Failed to load Smart Pick map from {}", id, e
            );
        }
    }

    public static void clear() {
        CACHE.clear();
    }

    public static class ReloadListener extends class_4080<Void> {

        @Override
        protected Void method_18789(class_3300 resourceManager, class_3695 profilerFiller) {
            return null;
        }

        @Override
        protected void apply(Void object, class_3300 resourceManager, class_3695 profilerFiller) {
            Platform.get().log("Clearing block pick cache.");
            CACHE.clear();
        }
    }

}
