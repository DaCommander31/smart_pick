package dev.dacommander31.smart_pick.mixin;

import dev.dacommander31.smart_pick.platform.Platform;
import dev.dacommander31.smart_pick.util.PickBlockCache;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Shadow
    static class_310 instance;

    @Shadow @Nullable
    public class_746 player;

    @ModifyVariable(
            method = "pickBlock",
            at = @At(
                    value = "STORE"
            ),
            ordinal = 0
    )
    private class_1799 smartPick$modifyPickedStack(class_1799 stack) {
        assert player != null;
        class_1661 inventory = player.method_31548();
        if (stack.method_7960() || inventory.method_7379(stack) || player.method_31549().field_7477) return stack;

        Map<class_1792, List<class_1792>> map = PickBlockCache.getCache();

        for (Map.Entry<class_1792, List<class_1792>> entry : map.entrySet()) {
            class_1792 targetItem = entry.getKey();

            if (!stack.method_31574(targetItem)) continue;


            for (class_1792 item : entry.getValue()) {
                if (player.method_31548().method_43256(itemStack -> itemStack.method_31574(item))) {
                    if (Platform.get().actionbarMessages()) {
                        instance.field_1705.method_1758(class_2561.method_43471("smart_pick.pick"), false);
                    }
                    return new class_1799(item);
                }
            }
        }

        return stack;
    }
}
