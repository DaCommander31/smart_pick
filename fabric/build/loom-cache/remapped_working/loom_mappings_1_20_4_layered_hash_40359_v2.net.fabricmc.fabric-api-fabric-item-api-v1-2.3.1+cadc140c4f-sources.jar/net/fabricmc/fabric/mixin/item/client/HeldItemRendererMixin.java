/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.item.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.fabric.api.item.v1.FabricItem;
import net.minecraft.class_310;
import net.minecraft.class_759;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

/**
 * Allow canceling the held item update animation if {@link FabricItem#allowNbtUpdateAnimation} returns false.
 */
@Mixin(class_759.class)
public class HeldItemRendererMixin {
	@Shadow
	private ItemStack mainHand;

	@Shadow
	private ItemStack offHand;

	@Shadow
	@Final
	private class_310 client;

	@Inject(method = "updateHeldItems", at = @At("HEAD"))
	private void modifyProgressAnimation(CallbackInfo ci) {
		// Modify main hand
		ItemStack newMainStack = client.field_1724.method_6047();

		if (mainHand.getItem() == newMainStack.getItem()) {
			if (!mainHand.getItem().allowNbtUpdateAnimation(client.field_1724, InteractionHand.MAIN_HAND, mainHand, newMainStack)) {
				mainHand = newMainStack;
			}
		}

		// Modify off hand
		ItemStack newOffStack = client.field_1724.method_6079();

		if (offHand.getItem() == newOffStack.getItem()) {
			if (!offHand.getItem().allowNbtUpdateAnimation(client.field_1724, InteractionHand.OFF_HAND, offHand, newOffStack)) {
				offHand = newOffStack;
			}
		}
	}
}
