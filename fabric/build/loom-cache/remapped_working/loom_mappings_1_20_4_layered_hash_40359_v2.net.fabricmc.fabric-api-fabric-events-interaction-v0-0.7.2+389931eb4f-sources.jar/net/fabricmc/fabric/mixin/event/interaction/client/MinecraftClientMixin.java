/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.event.interaction.client;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import net.fabricmc.fabric.api.event.client.player.ClientPickBlockApplyCallback;
import net.fabricmc.fabric.api.event.client.player.ClientPickBlockCallback;
import net.fabricmc.fabric.api.event.client.player.ClientPickBlockGatherCallback;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_437;
import net.minecraft.class_634;
import net.minecraft.class_636;
import net.minecraft.class_746;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
	private boolean fabric_itemPickCancelled;
	private boolean fabric_attackCancelled;

	@SuppressWarnings("deprecation")
	private ItemStack fabric_emulateOldPick() {
		class_310 client = (class_310) (Object) this;
		ClientPickBlockCallback.Container ctr = new ClientPickBlockCallback.Container(ItemStack.EMPTY);
		ClientPickBlockCallback.EVENT.invoker().pick(client.field_1724, client.field_1765, ctr);
		return ctr.getStack();
	}

	@Inject(at = @At("HEAD"), method = "doItemPick", cancellable = true)
	private void fabric_doItemPickWrapper(CallbackInfo info) {
		class_310 client = (class_310) (Object) this;

		// Do a "best effort" emulation of the old events.
		ItemStack stack = ClientPickBlockGatherCallback.EVENT.invoker().pick(client.field_1724, client.field_1765);

		// TODO: Remove in 0.3.0
		if (stack.isEmpty()) {
			stack = fabric_emulateOldPick();
		}

		if (stack.isEmpty()) {
			// fall through
		} else {
			info.cancel();

			// I don't like that we clone vanilla logic here, but it's our best bet for now.
			Inventory playerInventory = client.field_1724.method_31548();

			if (client.field_1724.method_31549().field_7477 && class_437.method_25441() && client.field_1765.method_17783() == HitResult.Type.BLOCK) {
				BlockEntity be = client.field_1687.method_8321(((BlockHitResult) client.field_1765).getBlockPos());

				if (be != null) {
					addBlockEntityNbt(stack, be);
				}
			}

			stack = ClientPickBlockApplyCallback.EVENT.invoker().pick(client.field_1724, client.field_1765, stack);

			if (stack.isEmpty()) {
				return;
			}

			if (client.field_1724.method_31549().field_7477) {
				playerInventory.setPickedItem(stack);
				client.field_1761.method_2909(client.field_1724.method_5998(InteractionHand.MAIN_HAND), 36 + playerInventory.selected);
			} else {
				int slot = playerInventory.findSlotMatchingItem(stack);

				if (slot >= 0) {
					if (Inventory.isHotbarSlot(slot)) {
						playerInventory.selected = slot;
					} else {
						client.field_1761.method_2916(slot);
					}
				}
			}
		}
	}

	@Shadow
	protected abstract void addBlockEntityNbt(ItemStack itemStack_1, BlockEntity blockEntity_1);

	@ModifyVariable(at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerInventory;getSlotWithStack(Lnet/minecraft/item/ItemStack;)I", shift = At.Shift.BEFORE), method = "doItemPick", ordinal = 0)
	public ItemStack modifyItemPick(ItemStack stack) {
		class_310 client = (class_310) (Object) this;
		ItemStack result = ClientPickBlockApplyCallback.EVENT.invoker().pick(client.field_1724, client.field_1765, stack);
		fabric_itemPickCancelled = result.isEmpty();
		return result;
	}

	@Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerInventory;getSlotWithStack(Lnet/minecraft/item/ItemStack;)I"), method = "doItemPick", cancellable = true)
	public void cancelItemPick(CallbackInfo info) {
		if (fabric_itemPickCancelled) {
			info.cancel();
		}
	}

	@Shadow
	private class_746 player;

	@Shadow
	public abstract class_634 getNetworkHandler();

	@Shadow
	@Final
	public class_315 options;

	@Shadow
	@Nullable
	public class_636 interactionManager;

	@Inject(
			at = @At(
					value = "INVOKE",
					target = "net/minecraft/client/network/ClientPlayerInteractionManager.interactEntityAtLocation(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/hit/EntityHitResult;Lnet/minecraft/util/Hand;)Lnet/minecraft/util/ActionResult;"
			),
			method = "doItemUse",
			cancellable = true,
			locals = LocalCapture.CAPTURE_FAILHARD
	)
	private void injectUseEntityCallback(CallbackInfo ci, InteractionHand[] hands, int i1, int i2, InteractionHand hand, ItemStack stack, EntityHitResult hitResult, Entity entity) {
		InteractionResult result = UseEntityCallback.EVENT.invoker().interact(player, player.method_5770(), hand, entity, hitResult);

		if (result != InteractionResult.PASS) {
			if (result.consumesAction()) {
				Vec3 hitVec = hitResult.getLocation().subtract(entity.getX(), entity.getY(), entity.getZ());
				getNetworkHandler().method_52787(ServerboundInteractPacket.createInteractionPacket(entity, player.method_5715(), hand, hitVec));
			}

			if (result.shouldSwing()) {
				player.method_6104(hand);
			}

			ci.cancel();
		}
	}

	@Inject(
			method = "handleInputEvents",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z",
					ordinal = 0
			)
	)
	private void injectHandleInputEventsForPreAttackCallback(CallbackInfo ci) {
		int attackKeyPressCount = ((KeyBindingAccessor) options.field_1886).fabric_getTimesPressed();

		if (options.field_1886.method_1434() || attackKeyPressCount != 0) {
			fabric_attackCancelled = ClientPreAttackCallback.EVENT.invoker().onClientPlayerPreAttack(
					(class_310) (Object) this, player, attackKeyPressCount
			);
		} else {
			fabric_attackCancelled = false;
		}
	}

	@Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
	private void injectDoAttackForCancelling(CallbackInfoReturnable<Boolean> cir) {
		if (fabric_attackCancelled) {
			cir.setReturnValue(false);
		}
	}

	@Inject(method = "handleBlockBreaking", at = @At("HEAD"), cancellable = true)
	private void injectHandleBlockBreakingForCancelling(boolean breaking, CallbackInfo ci) {
		if (fabric_attackCancelled) {
			if (interactionManager != null) {
				interactionManager.method_2925();
			}

			ci.cancel();
		}
	}
}
