package dev.dacommander31.smart_pick.modmenu;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import dev.dacommander31.smart_pick.SmartPickConfig;
import me.shedaniel.autoconfig.AutoConfig;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;

public class ModConfigScreenFactory implements ConfigScreenFactory<@NotNull class_437> {
    @Override
    public class_437 create(class_437 parent) {
        return AutoConfig.getConfigScreen(SmartPickConfig.class, parent).get();
    }
}
